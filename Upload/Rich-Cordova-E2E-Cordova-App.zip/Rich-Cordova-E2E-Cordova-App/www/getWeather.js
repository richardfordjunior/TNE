var weatherDataEl = document.getElementById('cloudResponse');
console.log(weatherDataEl.innerHTML);

function success(res){
weatherDataEl.innerHTML = res;
}

function fail(err,msg){
	alert('Failed to get weather. Cloud connectivity issue');
}

function getWeather(lat, lon){
	$fh.cloud(
		{
			path: '/weather/'+ lat + '/' + lon,
			method : 'GET'
		}
	,success,fail)

}