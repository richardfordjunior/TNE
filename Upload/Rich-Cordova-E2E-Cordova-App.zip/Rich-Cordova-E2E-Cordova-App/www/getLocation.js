

document.getElementById('get-location-btn').onclick = getLocation;
var geocoder = new google.maps.Geocoder();
var lat;
var lon;
var currentStatusText = document.getElementById('my-location');
var currentCityText = document.getElementById('my-city');
var result;
function getLocation(){
	 var options={
	  enableHighAccuracy:false,
	  timeout:30000

	 };

  currentStatusText.innerHTML = 'Getting Location!';
	currentCityText.innerHTML = 'Getting City!';
	navigator.geolocation.getCurrentPosition(
	     onLocationSuccess,
	     onLocationFail,
	     options
	);


	function onLocationFail(err){
       console.log(err);
	}

    function initialize() {
    	//geocoder = new google.maps.Geocoder();
    	console.log('Geocoder initialized at: ' + new Date());
  	}

	function onLocationSuccess(position){
      lat = position.coords.latitude.toFixed(2);
      lon = position.coords.longitude.toFixed(2);
     var locationStr = 'Location at '+ new Date() +' is '+ lat +', ' + lon;
	 currentStatusText.innerHTML = locationStr  || 'Location could not be found';

	 if(position != null){
	 	initialize();
	    codeLatLng(lat,lon,position);
	 }
	}

	function codeLatLng(latit,longit,position){
	     latit = lat;
	     longit = lon;
      	var latlng = new google.maps.LatLng(latit, longit);
      	geocoder.geocode({'latLng': latlng}, function(results, status) {
		 if (status == google.maps.GeocoderStatus.OK){
		 		if(results[1]){
		 			result = results[1].address_components[2].long_name + ', ' +
		 			results[1].address_components[1].long_name + ', ' +
		 			results[1].address_components[3].long_name;
		 			currentCityText.innerHTML = result || 'City not located.';
		 		}
		 }
	}
)};
}
