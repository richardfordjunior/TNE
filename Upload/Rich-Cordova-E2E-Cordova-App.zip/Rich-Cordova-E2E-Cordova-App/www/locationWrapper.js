var App = {};
App.Utils = {};

//Namespace 
App.Utils.getLocation = function (callback){
    function success(position){
        callback(null,position);
    }
    function fail(error){
		callback(error,null);
    }
	navigator.geolocation.getCurrentPosition(success, fail,{
		enableHighAccuracy: false
	});
}