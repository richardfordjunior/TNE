'use strict';
var chai = window.chai;
var expect = chai.expect;



describe('Location Wrapper',function(){

    this.timeout(30 * 1000);

	it ('Should get location succesfully', function(done){
		App.Utils.getLocation(function(err,location){
            expect(err).to.be.null;
            expect(location).to.be.an('object');
            done();
		});
	});
});