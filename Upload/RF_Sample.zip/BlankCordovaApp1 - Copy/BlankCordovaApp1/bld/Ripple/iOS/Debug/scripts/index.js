﻿/// <reference path="../createContact.html" />
/// <reference path="../createContact.html" />
// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkID=397704
// To debug code on page load in Ripple or on Android devices/emulators: launch your app, set breakpoints, 
// and then run "window.location.reload()" in the JavaScript Console.
(function () {
    "use strict";

    document.addEventListener( 'deviceready', onDeviceReady.bind( this ), false );
   
    function onDeviceReady() {
        // Handle the Cordova pause and resume events
        document.addEventListener( 'pause', onPause.bind( this ), false );
        document.addEventListener('resume', onResume.bind(this), false);
        // TODO: Cordova has been loaded. Perform any initialization that requires Cordova here.
        document.getElementById("click").onclick = function deviceInfo(acceleration) {
 
            var objDevice = {
                cordova: device.cordova,
                deviceOS: device.platform,
                deviceVersion: device.version,
                deviceID: device.uuid
            };
            var objConnection = {
                ethernet: Connection.ETHERNET,
                wifi: Connection.WIFI,
                cel2g: Connection.CELL_2G,
                cel3g: Connection.CELL_3G,
                cel4g: Connection.CELL_4G,
                none: Connection.NONE
            };
            var objMotion = {
                AccelerationX: acceleration.x,
                AccelerationY: acceleration.y,
                AccelerationZ: acceleration.z 
            };

            // create a new contact object
            var contact = navigator.contacts.create();
            contact.displayName = "Plumber";
            contact.nickname = "Plumber";            // specify both to support all devices

            // populate some fields
            var name = new ContactName();
            name.givenName = "Jane";
            name.familyName = "Doe";
            contact.name = name;

            // save to device
            //contact.save(onSuccess, onError);


            document.getElementById("lbl1").innerText = "Cordova: " + objDevice.cordova + "\n" + "OS: " + objDevice.deviceOS + "\n" + "Version: " + objDevice.deviceVersion + "\n"+ "Device ID: " + objDevice.deviceID;
            document.getElementById("lbl2").innerText = "Ethernet: " + objConnection.ethernet + "\n" + "WIFI: " + objConnection.wifi + objConnection.cel2g + objConnection.cel3g + objConnection.cel4g + objConnection.none;
            document.getElementById("lbl3").innerText = "Motion: x" + objMotion.AccelerationX + "\n" + "y: " + objMotion.AccelerationY + "\n" + "z: " + objMotion.AccelerationZ;

           
        };

        //document.getElementById("click1").onclick = function openNewWindow() {
        //    var ref = window.open('http://cnn.com', '_blank', 'location=yes');
        //};

        //document.getElementById("click1").onclick = function onSuccess(contacts) {
        //    alert('Found ' + contacts.length + ' contacts.');
        document.getElementsById("click2").onclick = function test() { alert(); };

    };

  
    function onPause() {
        // TODO: This application has been suspended. Save application state here.
    };

    function onResume() {
        // TODO: This application has been reactivated. Restore application state here.
    };




    function onError(contactError) {
        alert("Error = " + contactError.code);
    };

   
} )();